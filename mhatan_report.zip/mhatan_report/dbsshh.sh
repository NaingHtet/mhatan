#!/bin/sh

ssh -f -N -L 5433:tomcat.cs.lafayette.edu:5432 htetn@tomcat.cs.lafayette.edu
