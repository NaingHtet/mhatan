
var AM = require('./modules/account-manager');

module.exports = function(app) {

	app.get('/home', function(req, res) {
	    if (req.session.user == null){
	// if user is not logged-in redirect back to login page //
	        res.redirect('/');
	    }   else{
			res.render('entry', {
				locals: {
					title : 'Welcome! '+req.session.user.user,
					udata : req.session.user
				}
			});
		}
	});


	app.post('/addEntry', function(req, res){
		//console.log(req.session.user);
	    if (req.session.user == null){
	// if user is not logged-in redirect back to login page //
	        res.redirect('/');
	    }   else{
	    	//console.log(req.session.user);
	    	console.log(req.body);
			if (req.body.entry_text != undefined) {
				AM.addEntry(req.session.user.user_id,req.body, function(o,entry_id){
					if (o){
						if(req.body.entry_pics != undefined){
							AM.addPics(req.session.user.user_id,req.body.entry_pics,entry_id,function(o){
								if(o){
									res.send('ok',200);
								}
							});
						}
						res.send('ok', 200);	
					}	else{
						res.send('error-creating-post', 400);
					}
				});
			}
		}
	});

	app.post('/diary', function(req, res){
		//console.log(req.session.user);
	    if (req.session.user == null){
	// if user is not logged-in redirect back to login page //
	        res.redirect('/');
	    }   else{
			if (req.body.diary_name != undefined) {
				AM.addDiary(req.session.user.user_id,req.body, function(o){
					if (o){
						res.redirect('/diary');
					}	else{
						res.send('error-creating-diary', 400);
					}
				});
			}
		}
	});

// main login page //
	app.get('/', function(req, res){
	// check if the user's credentials are saved in a cookie //
		if ( req.cookies.email == undefined || req.cookies.pass == undefined){
			res.render('login', { locals: { title: 'Hello' }});
		}	else{
	// attempt automatic login //
			AM.manualLogin(req.cookies.email, req.cookies.pass, function(e,o){
				if (o != null){
				    req.session.user = o;
					res.redirect('/home');
				}	else{
					res.render('login', { locals: { title: 'Hello' }});
				}
			});
		}
	});
	
	app.post('/', function(req, res){
		AM.manualLogin(req.param('email'), req.param('pass'), function(e,o){
			if (!o){
				res.send(e, 400);
			}	else{
			    req.session.user = o;
				if (req.param('remember-me') == 'true'){
					res.cookie('email', o.email, { maxAge: 900000 });
					res.cookie('pass', req.param('pass'), { maxAge: 900000 });
				}
				res.send(o, 200);
				//console.log('no user');
			}
		});
	});
	
	
// creating new accounts //
	
	app.get('/signup', function(req, res) {
		res.render('signup', {  locals: { title: 'Signup' }});
	});
	
	app.post('/signup', function(req, res){
		AM.signup({
			email 	: req.param('email'),
			user 	: req.param('user'),
			pass	: req.param('pass'),
		}, function(e, o){
			if (e){
				res.send(e, 400);
			}	else{
				console.log('done creating');
				res.send('ok', 200);
			}
		});
	});
	
// view & delete accounts //
	
	app.get('/print', function(req, res) {
		AM.getAllRecords( function(e, accounts){
			res.render('print', { locals: { title : 'Account List', accts : accounts } });
		})
	});

	app.post('/entry',function(req,res) {
		AM.getEntries(req.body.user_id,function(e,edata){
			if(!e){
				res.contentType('json');
				res.send(JSON.stringify(edata));
				//console.log(res);
				//console.log(edata);
			}
			else{
				console.log(e);
			}
		});
	});
	app.post('/prevdayentry',function(req,res) {
		AM.getPrevDayEntries(req.body.day,req.body.user_id,function(e,edata){
			console.log(req.body);
			if(!e){
				console.log(edata);
				res.contentType('json');
				res.send(JSON.stringify(edata));
			}
			else{
				console.log(e);
			}
		});
	});
	app.post('/nextdayentry',function(req,res) {
		AM.getNextDayEntries(req.body.day,req.body.user_id,function(e,edata){
			if(!e){
				console.log(edata);
				res.contentType('json');
				res.send(JSON.stringify(edata));
			}
			else{
				console.log(e);
			}
		});
	});
	app.post('/prevmonthentry',function(req,res) {
		AM.getPrevMonthEntries(req.body.day,req.body.user_id,function(e,edata){
			if(!e){
				console.log(edata);
				res.contentType('json');
				res.send(JSON.stringify(edata));
			}
			else{
				console.log(e);
			}
		});
	});
	app.post('/nextmonthentry',function(req,res) {
		AM.getNextMonthEntries(req.body.day,req.body.user_id,function(e,edata){
			if(!e){
				//console.log(edata);
				res.contentType('json');
				res.send(JSON.stringify(edata));
			}
			else{
				console.log(e);
			}
		});
	});
	app.post('/prevyearentry',function(req,res) {
		AM.getPrevYearEntries(req.body.day,req.body.user_id,function(e,edata){
			if(!e){
				res.contentType('json');
				res.send(JSON.stringify(edata));
			}
			else{
				console.log(e);
			}
		});
	});
	app.post('/nextyearentry',function(req,res) {
		AM.getNextYearEntries(req.body.day,req.body.user_id,function(e,edata){
			if(!e){
				console.log(edata);
				res.contentType('json');
				res.send(JSON.stringify(edata));
			}
			else{
				console.log(e);
			}
		});
	});

	
	app.post('/delentry', function(req, res){
		AM.deleteEntry(req.body.id, function(e){
			if (!e){
				res.send('ok', 200);
			}	else{
				res.send('entry not found', 400);
			}
	    });
	});

	app.get('/diary', function(req, res) {
		if (req.session.user == null){
			// if user is not logged-in redirect back to login page //
			res.redirect('/');
		} else {
			AM.getDiaries( req.session.user.user_id, function(e, data) {
				res.render('diary', { locals: { title : 'Diary List', diaries : data } });
			})
		}
	});


	app.get('/logout', function(req, res){
		//console.log(res.cookies);
		res.clearCookie('email',{path:'/'});
		res.clearCookie('pass',{path:'/'});
		req.session.destroy(function(e){ res.redirect('/'); });
		//console.log(req.session);
	});
	
	app.get('/about', function(req, res){
		res.render('about', { title: 'About Mhatan'});
	});
	
	app.get('*', function(req, res) { res.render('404', { title: 'Page Not Found'}); });

};