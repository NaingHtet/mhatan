
/**
 * Module dependencies.
 */

var express = require('express');
var http = require('http');
var app = express();

require('./config')(app, express);
require('./server/router')(app);

var io = require('socket.io').listen(app.listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
}));

io.sockets.on('connection', function (socket) {
  console.log('connected');
  socket.on('url', function (data) {
  	socket.broadcast.emit('childurl', data);
  });
});