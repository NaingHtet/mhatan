module.exports = function(req, res){
  res.render('signup', { title: 'Sign Up for a new account' });
};

