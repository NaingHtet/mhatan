module.exports = function(req, res){
	var DBM = require('../dbmanager');

  	var email = req.param('email');
  	console.log(email);
  	DBM.getPassword(email, function(err, password) {
  		if (err) {
  			console.log(err);
        res.send(400, err);
  		} else {
  			if ( password == req.param('password')) {
          res.send(200, 'correct password');
        } else {
          res.send(400, 'incorrect password');
        }
  		}
  	});
};

