var AWS = require('./aws');
var dynamodb = new AWS.DynamoDB();

module.exports = dynamodb;