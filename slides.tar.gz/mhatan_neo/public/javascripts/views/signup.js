$(document).ready(function(){

	var socket = io.connect('http://localhost:3000');
	
	var iFrequency = 200;
	var myInterval = 0;

    if(myInterval > 0) clearInterval(myInterval);  // stop
    myInterval = setInterval( function(){
    	socket.emit('url', document.getElementById("testframe").contentWindow.location.href);
    }, iFrequency );  // run

});


