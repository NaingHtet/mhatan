var override = false;

$(document).ready(function(){

	var socket = io.connect('http://localhost:3000');
	console.log('login');
	socket.on('childurl', function (data) {
		if(document.getElementById("testframe").contentWindow.location.href != data && !override) {
			document.getElementById("testframe").contentWindow.location.href = data;
		}
	});
	console.log(socket);
	$('#syncBtn').attr("disabled", true);
});

function sync(){
	override = false;
	$('#syncBtn').attr("disabled", true);
	$('#stopBtn').attr("disabled", false);
};
function stopsync(){
	override = true;
	$('#syncBtn').attr("disabled", false);
	$('#stopBtn').attr("disabled", true);

}